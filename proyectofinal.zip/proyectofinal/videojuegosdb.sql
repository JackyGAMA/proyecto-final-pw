CREATE DATABASE videojuegosdb;
USE  videojuegosdb;
CREATE TABLE videojuegos(
id INT PRIMARY KEY AUTO_INCREMENT,
titulo VARCHAR(100) NOT NULL,
genero VARCHAR(50),
plataforma VARCHAR(50),
precio VARCHAR(50),
clasificacion_edad VARCHAR(50),
imagen_url VARCHAR(255));

INSERT INTO videojuegos (id, titulo, genero, plataforma, precio, clasificacion_edad, imagen_url) VALUES
(1, 'The Legend of Zelda', 'Aventura', 'Nintendo', '59.99', 'E', 'https://www.zelda.com/breath-of-the-wild/assets/icons/BOTW-Share_icon.jpg'),
(2, 'Minecraft', 'Aventura', 'PC', '26.95', 'E10+', 'https://www.minecraft.net/content/dam/games/minecraft/key-art/PC_Bundle_Deluxe_Desktop.jpg'),
(3, 'The Witcher 3', 'RPG', 'PC', '39.99', 'M', 'https://cdn_l_thewitcher.cdprojektred.com/meta/TW3NG_thumbnail_en.png'),
(4, 'God of War', 'Acción', 'PlayStation', '49.99', 'M', 'https://cdn1.epicgames.com/offer/3ddd6a590da64e3686042d108968a6b2/EGS_GodofWar_SantaMonicaStudio_S1_2560x1440-5d74d9b240bba8f2c40920dcde7c5c67_2560x1440-5d74d9b240bba8f2c40920dcde7c5c67'),
(5, 'Hollow Knight', 'Metroidvania', 'PC, Nintendo Switch, PlayStation', '14.99', 'E', 'https://assets.nintendo.com/image/upload/c_fill,w_1200/q_auto:best/f_auto/dpr_2.0/ncom/software/switch/70010000003208/4643fb058642335c523910f3a7910575f56372f612f7c0c9a497aaae978d3e51'),
(6, 'Celeste', 'Plataformas', 'PC, Xbox, PlayStation, Nintendo Switch', '19.99', 'E', 'https://assets.nintendo.com/image/upload/ar_16:9,c_lpad,w_1240/b_white/f_auto/q_auto/ncom/software/switch/70010000006442/691ba3e0801180a9864cc8a7694b6f98097f9d9799bc7e3dc6db92f086759252'),
(7, 'Disco Elysium', 'RPG', 'PC, PlayStation, Xbox', '39.99', 'M', 'https://assets.nintendo.com/image/upload/c_fill,w_1200/q_auto:best/f_auto/dpr_2.0/ncom/software/switch/70010000044922/df5237749af09dda942147e22f49a0118b98fa7b5081cf53b31e1bd6530e7a23'),
(8, 'Slay the Spire', 'Cartas/Roguelike', 'PC, Xbox, PlayStation, Nintendo Switch', '24.99', 'E', 'https://assets.nintendo.com/image/upload/c_fill,w_1200/q_auto:best/f_auto/dpr_2.0/ncom/software/switch/70010000012389/6d1d0c45eef34e20f352bd2222e036b619fa382f47385f2a8f80c137a523533e'),
(9, 'Stray', 'Aventura', 'PlayStation', '49.99', 'M', 'https://gmedia.playstation.com/is/image/SIEPDC/stray-sku-keyart-01-ps5-en-23jun20?$800px$'),
(10, 'Stardew Valley', 'Simulación', 'PC, Xbox, PlayStation, Nintendo Switch', '14.99', 'E', 'https://assets.nintendo.com/image/upload/ar_16:9,b_auto:border,c_lpad/b_white/f_auto/q_auto/dpr_1.5/ncom/software/switch/70010000001801/9c33645aee20fb323e579cd75036df000f2322de1be04662c989d42047ffbfdb'),
(11, 'Dead Cells', 'Metroidvania', 'PC, Xbox, PlayStation, Nintendo Switch', '24.99', 'T', 'https://assets.nintendo.com/image/upload/q_auto/f_auto/ncom/software/switch/70010000007706/bb0e6f620098683ff06d306700a18c945adbcc897aa4cc65f41f97dd69621745'),
(12, 'Hades', 'Roguelike', 'PC, Xbox, PlayStation, Nintendo Switch', '29.99', 'T', 'https://assets.nintendo.com/image/upload/ar_16:9,c_lpad,w_1240/b_white/f_auto/q_auto/ncom/software/switch/70010000033131/dbc8c55a21688b446a5c57711b726956483a14ef8c5ddb861f897c0595ccb6b5'),
(13, 'Outer Wilds', 'Aventura', 'PC, Xbox, PlayStation', '24.99', 'E', 'https://www.nintendo.com/eu/media/images/10_share_images/games_15/nintendo_switch_4/H2x1_NSwitch_OuterWilds.jpg'),
(14, 'Call of Duty Modern Warfare III', 'Shooter de acción', 'Xbox', '39.99', 'M', 'https://assets.xboxservices.com/assets/64/ea/64ea9f0e-6c8f-44f9-8866-429edbad9784.jpg?n=2626994_Poster-Image-1084_1920x1080_02.jpg'),
(15, 'Katana ZERO', 'Acción', 'PC, Xbox, Nintendo Switch', '14.99', 'M', 'https://assets.nintendo.com/image/upload/c_fill,w_1200/q_auto:best/f_auto/dpr_2.0/ncom/software/switch/70010000017136/58ff94c4934232a14fd6f3ee93730cd04c32dc248bae5514b582f2bc635a0d65'),
(16, 'Animal Crossing: New Horizons', 'Simulación', 'Nintendo Switch', '20.99', 'A', 'https://assets.nintendo.com/image/upload/ar_16:9,c_lpad,w_1240/b_white/f_auto/q_auto/ncom/software/switch/70010000027619/9989957eae3a6b545194c42fec2071675c34aadacd65e6b33fdfe7b3b6a86c3a'),
(17, 'Undertale', 'RPG', 'PC, PlayStation, Nintendo Switch', '9.99', 'E', 'https://assets.nintendo.com/image/upload/q_auto/f_auto/ncom/software/switch/70010000009921/44bea8c565db26c0c470a6325a47c9ea031633945cb91e4b5e1b1a39b01a2cdb');